# Indicaciones
    - Color-texto-1: #766df4
    - Color-texto-2: #737491
    - Background-color-1: #f7f7fc
    - Background-color-2: #37384e
    - Fuente: Inter (https://fonts.google.com/specimen/Inter?preview.text_type=custom)
    - Iconos: puedes utilizar cualquier página que proporcione estos recursos

# Web
https://around.createx.studio/demo-food-blog.html